# CoolPilot: Game Assistant
Android app (Kotlin) for gamers on low-end phones.

- Live Monitor: ping, network speed, battery temperature and charge in a notification (no overlay permission). Warns at 40 C and 45 C (changeable), repeats, snooze button.
- Game Booster: asks Android to close background apps and shows free RAM.
- Best Settings Advisor: Gemini suggests graphics/FPS settings for your phone and game.
- Screen Assist: foreground service keeps the latest small screen picture in memory; press Ask in the notification, speak, and Gemini answers by voice. Auto tips option. Time limit (default 60 min). Nothing saved.

Enter your own Gemini API key in the app (aistudio.google.com/apikey).

Build online: push to GitHub, open Actions > Build APK, download the CoolPilot-debug-apk artifact.
Privacy policy page: docs/index.html (GitHub Pages: Settings > Pages > main /docs).
