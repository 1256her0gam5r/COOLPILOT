package com.coolpilot

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Short opening: "COOL" fades in, then "AI" slams in with a "dang" sound. Plain views, no heavy animation. */
class SplashActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val green = Color.parseColor("#00E5FF")
        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 38f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(green); alpha = 0f
        }
        val cool = label("COOL")
        val pilot = label(" PILOT").apply { scaleX = 2.5f; scaleY = 2.5f }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(cool); addView(pilot)
        }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(row, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        })

        cool.animate().alpha(1f).setDuration(500).start()
        handler.postDelayed({
            pilot.alpha = 1f
            pilot.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            player = MediaPlayer.create(this, R.raw.dang)?.apply {
                setOnCompletionListener { it.release(); player = null }
                start()
            }
        }, 700)
        handler.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, 1900)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release(); player = null
        super.onDestroy()
    }
}
