package com.coolpilot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.net.TrafficStats
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.view.Display
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale

/**
 * Shows live ping, network speed, battery temperature and charge in ONE notification (no overlay permission).
 * Warns when the battery temperature crosses the limits set in the app.
 */
class MonitorService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private lateinit var nm: NotificationManager

    private var lastRx = 0L
    private var lastTx = 0L
    private var lastT = 0L
    private var pingMs = -1
    private var snoozeUntil = 0L
    private var lastAlertAt = 0L
    private var level = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        nm = getSystemService(NotificationManager::class.java)
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_SNOOZE -> {
                snoozeUntil = SystemClock.elapsedRealtime() + 10 * 60_000L
                nm.cancel(ALERT_ID)
                return START_NOT_STICKY
            }
        }
        if (running) return START_NOT_STICKY
        running = true
        createChannels()
        val first = buildMain("CoolPilot is starting\u2026", "", "")
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(MAIN_ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(MAIN_ID, first)
        job = scope.launch { loop() }
        return START_NOT_STICKY
    }

    private suspend fun loop() {
        var tick = 0
        while (scope.isActive) {
            val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
            val lvl = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (lvl >= 0 && scale > 0) lvl * 100 / scale else -1
            val charging = (bat?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0

            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            val t = SystemClock.elapsedRealtime()
            var down = 0.0
            var up = 0.0
            if (lastT > 0 && t > lastT && rx >= 0 && tx >= 0) {
                val s = (t - lastT) / 1000.0
                down = ((rx - lastRx) / 1024.0 / s).coerceAtLeast(0.0)
                up = ((tx - lastTx) / 1024.0 / s).coerceAtLeast(0.0)
            }
            lastRx = rx; lastTx = tx; lastT = t

            if (tick % 2 == 0) pingMs = measurePing()
            tick++

            val hz = (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
                .getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate?.toInt() ?: 0

            val title = if (pingMs < 0) "CoolPilot \u2022 No connection"
            else "CoolPilot \u2022 Ping $pingMs ms (${quality(pingMs)})"
            val tempTxt = String.format(Locale.US, "%.1f\u00B0C", temp)
            val line = "\u2193 ${fmt(down)}  \u2191 ${fmt(up)}  \u2022  $tempTxt"
            val big = "\u2193 ${fmt(down)}   \u2191 ${fmt(up)}\n" +
                "Temperature: $tempTxt\n" +
                "Battery: ${if (pct >= 0) "$pct%" else "?"}${if (charging) " (charging)" else ""}\n" +
                "Screen refresh rate: $hz Hz"
            nm.notify(MAIN_ID, buildMain(title, line, big))

            checkTemp(temp)
            delay(2000)
        }
    }

    private fun checkTemp(temp: Float) {
        if (temp <= 0f) return
        val warn = Prefs.warnTemp(this).toFloat()
        val crit = Prefs.critTemp(this).toFloat()
        val newLevel = when {
            temp >= crit -> 2
            temp >= warn -> 1
            level > 0 && temp >= warn - 1f -> 1
            else -> 0
        }
        val now = SystemClock.elapsedRealtime()
        if (newLevel > 0) {
            val interval = if (newLevel == 2) 60_000L else 120_000L
            if (now >= snoozeUntil && (newLevel > level || now - lastAlertAt >= interval)) {
                postAlert(temp, newLevel)
                lastAlertAt = now
            }
        } else if (level > 0) {
            nm.cancel(ALERT_ID)
            val n = Notification.Builder(this, CH_ALERT)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Phone cooled down")
                .setContentText("You're good to play.")
                .setTimeoutAfter(15_000)
                .setAutoCancel(true)
                .build()
            nm.notify(COOL_ID, n)
        }
        level = newLevel
    }

    private fun postAlert(temp: Float, lvl: Int) {
        val t = String.format(Locale.US, "%.1f\u00B0C", temp)
        val title: String
        val text: String
        if (lvl >= 2) {
            title = "Phone is overheating! ($t)"
            text = "Close the game and let your phone cool down, or it will lag."
        } else {
            title = "Phone getting warm ($t)"
            text = "Lower graphics or take a short break to keep your game smooth."
        }
        val n = Notification.Builder(this, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .addAction(action("Snooze 10 min", ACTION_SNOOZE, 11))
            .build()
        nm.notify(ALERT_ID, n)
    }

    private fun measurePing(): Int = try {
        val s = Socket()
        val t0 = SystemClock.elapsedRealtime()
        s.connect(InetSocketAddress("1.1.1.1", 443), 2000)
        val ms = (SystemClock.elapsedRealtime() - t0).toInt()
        s.close()
        ms
    } catch (e: Exception) { -1 }

    private fun quality(ms: Int) = when {
        ms < 60 -> "Excellent"
        ms < 100 -> "Good"
        ms < 150 -> "Fair"
        else -> "Poor"
    }

    private fun fmt(kb: Double) =
        if (kb >= 1024) String.format(Locale.US, "%.1f MB/s", kb / 1024)
        else String.format(Locale.US, "%.0f KB/s", kb)

    private fun svcPi(action: String, req: Int) = PendingIntent.getService(
        this, req, Intent(this, MonitorService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun action(title: String, act: String, req: Int) =
        Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), title, svcPi(act, req)).build()

    private fun buildMain(title: String, line: String, big: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH_MAIN)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(line)
            .setStyle(Notification.BigTextStyle().bigText(big.ifEmpty { line }))
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(action("Snooze alerts", ACTION_SNOOZE, 11))
            .addAction(action("Stop", ACTION_STOP, 12))
            .build()
    }

    private fun createChannels() {
        nm.createNotificationChannel(
            NotificationChannel(CH_MAIN, "Live stats", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Overheat alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400)
            }
        )
    }

    override fun onDestroy() {
        running = false
        scope.cancel()
        runCatching { nm.cancel(ALERT_ID) }
        super.onDestroy()
    }

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.coolpilot.MONITOR_STOP"
        const val ACTION_SNOOZE = "com.coolpilot.MONITOR_SNOOZE"
        private const val MAIN_ID = 1
        private const val ALERT_ID = 3
        private const val COOL_ID = 4
        private const val CH_MAIN = "monitor"
        private const val CH_ALERT = "alerts"
    }
}
