package com.coolpilot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Screen Assist: while running, the game screen is captured as small pictures kept ONLY in memory
 * (latest one replaces the old one). Press "Ask" in the notification, speak, and Gemini answers by voice
 * using your voice + the current screen. Nothing is saved to storage. Stops automatically at the time limit.
 */
class ScreenAssistService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val main = Handler(Looper.getMainLooper())
    private lateinit var nm: NotificationManager
    private val gemini by lazy { GeminiManager(this) }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    @Volatile private var latest: ByteArray? = null
    private var lastFrameAt = 0L

    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private val busy = AtomicBoolean(false)
    @Volatile private var tipsOn = false
    private var endAt = 0L
    @Volatile private var status = "Press Ask and speak"
    @Volatile private var reply = ""

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        nm = getSystemService(NotificationManager::class.java)
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_ASK -> { if (running) scope.launch { askByVoice() }; return START_NOT_STICKY }
            ACTION_TIPS -> {
                tipsOn = !tipsOn
                status = if (tipsOn) "Auto tips ON (checks the screen every 30 s)" else "Auto tips OFF. Press Ask and speak"
                refresh()
                return START_NOT_STICKY
            }
        }
        if (running) return START_NOT_STICKY

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        nm.createNotificationChannel(NotificationChannel(CH, "Screen Assist", NotificationManager.IMPORTANCE_LOW))
        endAt = SystemClock.elapsedRealtime() + Prefs.sessionMin(this) * 60_000L
        try {
            val n = build()
            when {
                Build.VERSION.SDK_INT >= 30 -> startForeground(
                    ID, n,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
                Build.VERSION.SDK_INT == 29 -> startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
                else -> startForeground(ID, n)
            }
        } catch (e: Exception) {
            stopSelf(); return START_NOT_STICKY
        }
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        running = true
        startCapture(code, data)
        tts = TextToSpeech(this) { st -> ttsReady = (st == TextToSpeech.SUCCESS) }
        scope.launch { sessionLoop() }
        return START_NOT_STICKY
    }

    private fun startCapture(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(code, data)
            projection = mp
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
            val dm = resources.displayMetrics
            val w = (dm.widthPixels * 0.5f).toInt().coerceAtLeast(2)
            val h = (dm.heightPixels * 0.5f).toInt().coerceAtLeast(2)
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            reader = r
            display = mp.createVirtualDisplay(
                "coolpilot", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, main
            )
            r.setOnImageAvailableListener({ ir ->
                val img = try { ir.acquireLatestImage() } catch (e: Exception) { null }
                    ?: return@setOnImageAvailableListener
                try {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastFrameAt < 1500) return@setOnImageAvailableListener
                    lastFrameAt = now
                    val p = img.planes[0]
                    val rowPx = p.rowStride / p.pixelStride
                    val full = Bitmap.createBitmap(rowPx, h, Bitmap.Config.ARGB_8888)
                    full.copyPixelsFromBuffer(p.buffer)
                    val bmp = Bitmap.createBitmap(full, 0, 0, w, h)
                    val out = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, 55, out)
                    latest = out.toByteArray()   // memory only, never written to storage
                    if (bmp !== full) full.recycle()
                    bmp.recycle()
                } finally {
                    img.close()
                }
            }, main)
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private suspend fun sessionLoop() {
        var lastTip = 0L
        while (scope.isActive) {
            val now = SystemClock.elapsedRealtime()
            if (endAt - now <= 0) {
                val n = Notification.Builder(this, CH)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle("Screen Assist stopped")
                    .setContentText("Time limit reached. Start again from the CoolPilot app.")
                    .setAutoCancel(true).build()
                nm.notify(ID + 1, n)
                stopSelf()
                return
            }
            refresh()
            if (tipsOn && !busy.get() && latest != null && now - lastTip >= 30_000) {
                lastTip = now
                autoTip()
            }
            delay(5000)
        }
    }

    private suspend fun autoTip() {
        if (!busy.compareAndSet(false, true)) return
        try {
            val jpeg = latest ?: return
            val t = gemini.ask(getString(R.string.tip_prompt), getString(R.string.assist_prompt), jpeg = jpeg).trim()
            when {
                t.startsWith("Error") -> { tipsOn = false; setReply(t) }
                t.startsWith("OK", ignoreCase = true) -> {}
                else -> { setReply(t); speak(t) }
            }
        } finally {
            busy.set(false)
        }
    }

    private suspend fun askByVoice() {
        if (!busy.compareAndSet(false, true)) return
        try {
            status = "Listening\u2026 speak now"
            refresh()
            runCatching { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150) }
            delay(300)
            val wav = record()
            if (wav == null) {
                status = "Didn't hear anything. Press Ask again."
                refresh()
                return
            }
            status = "Thinking\u2026"
            refresh()
            val a = gemini.ask(getString(R.string.voice_prompt), getString(R.string.assist_prompt), jpeg = latest, wav = wav)
            status = "Press Ask and speak"
            setReply(a)
            speak(a)
        } finally {
            busy.set(false)
        }
    }

    /** Records until you stop talking (max 10 s). Returns WAV bytes kept in memory, or null if no speech. */
    private fun record(): ByteArray? {
        val rate = 16000
        val chunk = rate / 10
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val ar = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(min, chunk * 8)
            )
        } catch (e: Exception) { return null }
        if (ar.state != AudioRecord.STATE_INITIALIZED) { ar.release(); return null }
        val buf = ShortArray(chunk)
        val out = ByteArrayOutputStream()
        var spoke = false
        var silentMs = 0
        var totalMs = 0
        try {
            ar.startRecording()
            while (totalMs < 10_000) {
                val n = ar.read(buf, 0, buf.size)
                if (n <= 0) break
                var sum = 0.0
                for (i in 0 until n) sum += buf[i].toDouble() * buf[i].toDouble()
                val rms = Math.sqrt(sum / n)
                val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until n) bb.putShort(buf[i])
                out.write(bb.array())
                totalMs += 100
                if (rms > 1000) { spoke = true; silentMs = 0 } else if (spoke) silentMs += 100
                if (spoke && silentMs >= 1200) break
                if (!spoke && totalMs >= 5000) break
            }
        } catch (e: Exception) {
            return null
        } finally {
            runCatching { ar.stop() }
            ar.release()
        }
        return if (spoke) wav(out.toByteArray(), rate) else null
    }

    private fun wav(pcm: ByteArray, rate: Int): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + pcm.size); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1)
        h.putInt(rate); h.putInt(rate * 2); h.putShort(2); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(pcm.size)
        return h.array() + pcm
    }

    private fun speak(text: String) {
        val clean = text.replace(Regex("[*#_`>]+"), "").replace(Regex("\\s+"), " ").trim()
        if (!ttsReady || clean.isEmpty()) return
        val hindi = clean.any { it in '\u0900'..'\u097F' }
        tts?.setLanguage(if (hindi) Locale("hi", "IN") else Locale.US)
        tts?.speak(clean.take(400), TextToSpeech.QUEUE_FLUSH, null, "cp")
    }

    private fun setReply(t: String) { reply = t.take(600); refresh() }

    private fun pi(action: String, req: Int) = PendingIntent.getService(
        this, req, Intent(this, ScreenAssistService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun act(title: String, action: String, req: Int) =
        Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), title, pi(action, req)).build()

    private fun build(): Notification {
        val mins = ((endAt - SystemClock.elapsedRealtime()) / 60_000L).coerceAtLeast(0) + 1
        val big = if (reply.isEmpty()) status else "$status\n\n$reply"
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("CoolPilot Screen Assist \u2022 $mins min left")
            .setContentText(status)
            .setStyle(Notification.BigTextStyle().bigText(big))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(act("Ask", ACTION_ASK, 21))
            .addAction(act(if (tipsOn) "Auto tips: ON" else "Auto tips: OFF", ACTION_TIPS, 22))
            .addAction(act("Stop", ACTION_STOP, 23))
            .build()
    }

    private fun refresh() { if (running) nm.notify(ID, build()) }

    override fun onDestroy() {
        running = false
        scope.cancel()
        latest = null
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        runCatching { tts?.shutdown() }
        super.onDestroy()
    }

    companion object {
        @Volatile var running = false
        const val ACTION_ASK = "com.coolpilot.ASSIST_ASK"
        const val ACTION_TIPS = "com.coolpilot.ASSIST_TIPS"
        const val ACTION_STOP = "com.coolpilot.ASSIST_STOP"
        private const val ID = 5
        private const val CH = "assist"
    }
}
