package com.coolpilot

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import kotlinx.coroutines.delay

/** Asks Android to end background processes of user-installed apps. Android may restart some of them. */
object Booster {

    private fun freeMb(am: ActivityManager): Long {
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.availMem / (1024 * 1024)
    }

    @Suppress("DEPRECATION")
    suspend fun run(ctx: Context): String {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pm = ctx.packageManager
        val before = freeMb(am)
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pkgs = pm.queryIntentActivities(launcher, 0).map { it.activityInfo.packageName }.toSet()
        var count = 0
        for (p in pkgs) {
            if (p == ctx.packageName) continue
            val info = try { pm.getApplicationInfo(p, 0) } catch (e: Exception) { continue }
            if (info.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
            am.killBackgroundProcesses(p)
            count++
        }
        delay(1000)
        val after = freeMb(am)
        val gained = (after - before).coerceAtLeast(0)
        return "Asked Android to close background processes of $count apps.\n" +
            "Free RAM: $before MB \u2192 $after MB (+$gained MB).\n" +
            "Tip: run this BEFORE you open your game. Android may restart some apps by itself."
    }
}
