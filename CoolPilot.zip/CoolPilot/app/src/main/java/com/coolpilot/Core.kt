package com.coolpilot

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Settings stored privately on-device. The API key is entered by the user, never hard-coded. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("coolpilot", Context.MODE_PRIVATE)

    private fun secure(c: Context): SharedPreferences = try {
        val mk = MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            c, "coolpilot_secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        c.getSharedPreferences("coolpilot_secure_fallback", Context.MODE_PRIVATE)
    }

    fun apiKey(c: Context) = secure(c).getString("key", "") ?: ""
    fun saveKey(c: Context, key: String) = secure(c).edit().putString("key", key.trim()).apply()

    fun model(c: Context) = sp(c).getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
    fun warnTemp(c: Context) = sp(c).getInt("warn", 40)
    fun critTemp(c: Context) = sp(c).getInt("crit", 45)
    fun sessionMin(c: Context) = sp(c).getInt("session", 60)
    fun consent(c: Context) = sp(c).getBoolean("consent", false)
    fun setConsent(c: Context) = sp(c).edit().putBoolean("consent", true).apply()

    fun saveLimits(c: Context, warn: Int, crit: Int, session: Int) {
        val w = warn.coerceIn(30, 60)
        val cr = crit.coerceIn(w + 1, 70)
        sp(c).edit().putInt("warn", w).putInt("crit", cr)
            .putInt("session", session.coerceIn(5, 60)).apply()
    }
}

/** Calls the official Gemini REST API (generateContent) directly with the user's own key. */
class GeminiManager(private val ctx: Context) {

    suspend fun ask(
        prompt: String,
        system: String = ctx.getString(R.string.sys_prompt),
        jpeg: ByteArray? = null,
        wav: ByteArray? = null
    ): String = withContext(Dispatchers.IO) {
        val key = Prefs.apiKey(ctx)
        if (key.isEmpty()) return@withContext ctx.getString(R.string.need_key)
        try {
            val parts = JSONArray().put(JSONObject().put("text", prompt))
            if (jpeg != null) parts.put(
                JSONObject().put(
                    "inline_data", JSONObject()
                        .put("mime_type", "image/jpeg")
                        .put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))
                )
            )
            if (wav != null) parts.put(
                JSONObject().put(
                    "inline_data", JSONObject()
                        .put("mime_type", "audio/wav")
                        .put("data", Base64.encodeToString(wav, Base64.NO_WRAP))
                )
            )
            val body = JSONObject()
                .put(
                    "system_instruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                )
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                .put("generationConfig", JSONObject().put("maxOutputTokens", 800))

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${Prefs.model(ctx)}:generateContent")
            val c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                .bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
                    .getOrNull() ?: text.take(200)
                return@withContext "Error $code: $msg"
            }
            val ps = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text", ""))
            sb.toString().trim().ifEmpty { "(No answer)" }
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }
}
