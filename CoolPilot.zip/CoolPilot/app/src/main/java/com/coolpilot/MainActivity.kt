package com.coolpilot

import android.Manifest
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val gemini by lazy { GeminiManager(this) }
    private lateinit var out: TextView
    private lateinit var monitorBtn: Button
    private lateinit var assistBtn: Button
    private var afterPerms: (() -> Unit)? = null

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val go = afterPerms
        afterPerms = null
        go?.invoke()
    }

    private val projection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScreenAssistService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", data)
            ContextCompat.startForegroundService(this, i)
            toast("Screen Assist started. Open your game and use the notification buttons.")
            delayedRefresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val accent = Color.parseColor("#00E5FF")
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 48)
        }
        fun title(t: String, size: Float, color: Int) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
        }
        fun note(t: String) = title(t, 13f, Color.parseColor("#9AA4B2"))
        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1F2A37"))
            setOnClickListener { onClick() }
        }
        fun field(hint: String, value: String = "") = EditText(this).apply {
            this.hint = hint; setText(value)
            setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#6B7686"))
        }

        root.addView(title("CoolPilot", 32f, accent).apply { gravity = Gravity.CENTER })
        root.addView(title("Game Assistant", 15f, Color.parseColor("#9AA4B2")).apply { gravity = Gravity.CENTER })

        // 1. Live monitor
        root.addView(title("\n1. Live Monitor", 18f, accent))
        root.addView(note("Ping, network speed, temperature and battery in one notification. Warns you before your phone overheats."))
        monitorBtn = button("") { toggleMonitor() }
        root.addView(monitorBtn)

        // 2. Booster
        root.addView(title("\n2. Game Booster", 18f, accent))
        root.addView(note("Asks Android to close background apps to free RAM. Run it before you open your game."))
        root.addView(button("Run Game Booster") {
            lifecycleScope.launch {
                out.text = "Working\u2026"
                out.text = Booster.run(this@MainActivity)
            }
        })

        // 3. Settings advisor
        root.addView(title("\n3. Best Settings Advisor", 18f, accent))
        root.addView(note("Tell the AI your phone and game. It suggests graphics and FPS settings."))
        val phone = field("Your phone model", "${Build.MANUFACTURER} ${Build.MODEL}")
        val game = field("Game (e.g. BGMI, Free Fire)")
        root.addView(phone); root.addView(game)
        root.addView(button("Get best settings") {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
            val ram = String.format("%.1f", mi.totalMem / 1073741824.0)
            val g = game.text.toString().trim()
            if (g.isEmpty()) { toast("Type the game name first"); return@button }
            val prompt = "Phone: ${phone.text} (Android ${Build.VERSION.RELEASE}, about $ram GB RAM). Game: $g. " +
                "Give the best in-game graphics, frame rate and other settings for smooth play with low heat on this phone. " +
                "Short plain-text bullet list, max 8 lines."
            lifecycleScope.launch {
                out.text = "Thinking\u2026"
                out.text = gemini.ask(prompt)
            }
        })

        out = TextView(this).apply {
            textSize = 14f; setTextColor(Color.WHITE); setTextIsSelectable(true)
            setPadding(0, 24, 0, 8)
        }
        root.addView(out)

        // 4. Screen assist
        root.addView(title("\n4. Screen Assist", 18f, accent))
        root.addView(note("The AI watches your screen while you play. Press \"Ask\" in the notification, speak, and it answers by voice. Keeps running when you leave the app. Stops by itself at the time limit. Nothing is saved."))
        assistBtn = button("") { toggleAssist() }
        root.addView(assistBtn)

        // Settings
        root.addView(title("\nSettings", 18f, accent))
        val key = field("Gemini API key", Prefs.apiKey(this)).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(note("Free key: aistudio.google.com/apikey"))
        val warn = field("Warning temperature \u00B0C", Prefs.warnTemp(this).toString()).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        val crit = field("Overheating temperature \u00B0C", Prefs.critTemp(this).toString()).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        val session = field("Screen Assist time limit (minutes, max 60)", Prefs.sessionMin(this).toString()).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        root.addView(key); root.addView(warn); root.addView(crit); root.addView(session)
        root.addView(button("Save settings") {
            Prefs.saveKey(this, key.text.toString())
            Prefs.saveLimits(
                this,
                warn.text.toString().toIntOrNull() ?: 40,
                crit.text.toString().toIntOrNull() ?: 45,
                session.text.toString().toIntOrNull() ?: 60
            )
            toast("Saved")
        })
        root.addView(button("Privacy Policy") { showPolicy() })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0D1117"))
            fitsSystemWindows = true
            addView(root)
        })

        refreshButtons()
        if (!Prefs.consent(this)) showConsent()
    }

    override fun onResume() {
        super.onResume()
        refreshButtons()
    }

    private fun refreshButtons() {
        monitorBtn.text = if (MonitorService.running) "Stop Live Monitor" else "Start Live Monitor"
        assistBtn.text = if (ScreenAssistService.running) "Stop Screen Assist" else "Start Screen Assist"
    }

    private fun delayedRefresh() { window.decorView.postDelayed({ refreshButtons() }, 700) }

    private fun need(list: List<String>, then: () -> Unit) {
        val missing = list.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) then() else { afterPerms = then; perms.launch(missing.toTypedArray()) }
    }

    private fun toggleMonitor() {
        if (MonitorService.running) {
            startService(Intent(this, MonitorService::class.java).setAction(MonitorService.ACTION_STOP))
            toast("Live Monitor stopped")
            delayedRefresh()
            return
        }
        val list = if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.POST_NOTIFICATIONS) else emptyList()
        need(list) {
            ContextCompat.startForegroundService(this, Intent(this, MonitorService::class.java))
            toast("Live Monitor started. Pull down the notification bar.")
            delayedRefresh()
        }
    }

    private fun toggleAssist() {
        if (ScreenAssistService.running) {
            startService(Intent(this, ScreenAssistService::class.java).setAction(ScreenAssistService.ACTION_STOP))
            toast("Screen Assist stopped")
            delayedRefresh()
            return
        }
        if (Prefs.apiKey(this).isEmpty()) { toast(getString(R.string.need_key)); return }
        val list = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        need(list) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                toast("Microphone permission is needed to talk to the AI")
            } else {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection.launch(mpm.createScreenCaptureIntent())
            }
        }
    }

    private fun showConsent() {
        AlertDialog.Builder(this)
            .setTitle(R.string.consent_title)
            .setMessage(R.string.consent_body)
            .setCancelable(false)
            .setPositiveButton(R.string.accept) { _, _ -> Prefs.setConsent(this) }
            .setNegativeButton(R.string.exit) { _, _ -> finish() }
            .setNeutralButton(R.string.privacy_policy) { _, _ -> showPolicy(); }
            .show()
    }

    private fun showPolicy() {
        val text = resources.openRawResource(R.raw.privacy_policy).bufferedReader().use { it.readText() }
            .replace("## ", "\n")
        val tv = TextView(this).apply { this.text = text; setPadding(40, 24, 40, 24); textSize = 14f }
        AlertDialog.Builder(this).setTitle(R.string.privacy_policy)
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton(R.string.ok, null).show()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
}
